<div class="wrapper">
<div class="cube">
<div class="one"><center><p style="padding-top: 80px;padding-bottom: 100px;">Jay swaminarayan</p></center></div>
<div class="two"><center><p style="padding-top: 80px;padding-bottom: 100px;">Jay swaminarayan</p></center></div>
<div class="three"><center><p style="padding-top: 80px;padding-bottom: 100px;">Jay swaminarayan</p></center></div>
<div class="four"><center><p style="padding-top: 80px;padding-bottom: 100px;">Jay swaminarayan</p></center></div>
<div class="five"><center><p style="padding-top: 80px;padding-bottom: 100px;">Jay swaminarayan</p></center></div>
<div class="six"><center><p style="padding-top: 80px;padding-bottom: 100px;">Jay swaminarayan</p></center></div>
</div>
</div>
<div id="container" class="container" >

<!--******************** START SESSION SETFLASH MESSAGES *****************************-->
       <?php if($this->session->flashdata('message')){?>
          <div class="alert alert-success">      
            <?php echo $this->session->flashdata('message')?>
          </div>
        <?php } ?>
<!--************************* END SESSION SETFLASH MESSAGES   ************************-->


        <br>
        <div align="center"> 
          <a href="<?php echo site_url('Welcome/add_data'); ?>">Click to add new Record</a>
        </div>
        <br>


<!--*************************  START  DISPLAY ALL THE RECODEDS *************************-->
		<div class="">
        <table class="table table-bordered table-hover table-striped display" id="example" >
            <thead>
            <tr>
                <th>No.</th>
                <th>User name</th>
                <th>Email</th>
                <th>Sex</th>
                <th>Address</th>
                <th>Image</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
              <?php
                if(isset($view_data) && is_array($view_data) && count($view_data)): $i=1;
                foreach ($view_data as $key => $data) { 
                ?>
                <tr <?php if($i%2==0){echo 'class="even"';}else{echo'class="odd"';}?>>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $data->username; ?></td>            
                    <td><?php echo $data->email; ?></td>
                    <td><?php echo $data->sex; ?></td>
                    <td><?php echo $data->address; ?></td>
                    <td><a id="single_image" href="<?php echo base_url();?>assets/uploaded_profile_pictures/<?php echo $data->user_image; ?>"><img src="<?php echo base_url();?>assets/uploaded_profile_pictures/<?php echo $data->user_image; ?>" style="width:200px;"/></a></td>
                    <td><a href="<?php echo site_url('Welcome/edit_data/'. $data->id.''); ?>">Edit</a></td>            
                    <td><a href="<?php echo site_url('Welcome/delete_data/'. $data->id.''); ?>">Delete</a></td>
                </tr>
                <?php
                    $i++;
                      }
                    else:
                ?>
                <tr>
                    <td colspan="7" align="center" >No Records Found..</td>
                </tr>
                <?php
                    endif;
                ?>

            </tbody>                                
        </table>
        </div>
        <div id="pagination">
		<!-- Show pagination links -->
		<ul class="pagination">
		<?php foreach ($links as $link) {
		echo '<li>';
		echo $link;
		echo '</li>';
		} ?>
		</ul>
	</div>
<!--*********************  END  DISPLAY ALL THE RECODEDS ******************************-->
</div>
