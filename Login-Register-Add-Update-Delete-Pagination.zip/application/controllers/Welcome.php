<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');                    /***** LOADING HELPER TO AVOID PHP ERROR ****/
        $this->load->model('Welcome_model','welcome'); /* LOADING MODEL * Welcome_model as welcome */
        $this->load->library('pagination');
    }


    /**************************  START FETCH OR VIEW FORM DATA ***************/
    public function index()
    {
		//$this->load->view('header');
        $this->data['view_data']= $this->welcome->view_data();
        $this->data['view_data']= $this->pagination();
        //$this->load->view('footer');
    }
    /****************************  END FETCH OR VIEW FORM DATA ***************/


    /****************************  START OPEN ADD FORM FILE ******************/
    public function add_data()
    {
		$this->load->view('header');
        $this->load->view('add');
        $this->load->view('footer');
    }
    /****************************  END OPEN ADD FORM FILE ********************/

    
    /****************************  START INSERT FORM DATA ********************/
    public function submit_data()
    {
		if(!empty($_FILES['user_image']['name']))
		{
			$upload_data = $this->welcome->do_upload('user_image');
			
			$file_name = $upload_data['file_name'];
			
		//	$path = "assets/uploaded_profile_pictures/".$file_name;
			//unlink($path);
		}
		
    $data = array('username'                   => $this->input->post('username'),
                  'email'                      => $this->input->post('email'),
                  'sex'                        => $this->input->post('sex'),
                  'address'                    => $this->input->post('address'),
                  'user_image' => $file_name,
                  'created_date'               => date("m/d/y h:i:s"),
                  'status'                     => 'Y');
    
    $insert = $this->welcome->insert_data($data);
    $this->session->set_flashdata('message', 'Your data inserted Successfully..');
    redirect('welcome/index');
    }
    /****************************  END INSERT FORM DATA ************************/


    /****************************  START FETCH OR VIEW FORM DATA ***************/
    public function view_data()
    {
    $this->data['view_data']= $this->welcome->view_data();
    $this->load->view('welcome_message', $this->data, FALSE);
    }
    /****************************  END FETCH OR VIEW FORM DATA ***************/

    
    /****************************  START OPEN EDIT FORM WITH DATA *************/
    public function edit_data($id)
    {
	$this->load->view('header');	
    $this->data['edit_data']= $this->welcome->edit_data($id);
    $this->load->view('edit', $this->data, FALSE);
    $this->load->view('footer');
    }
    /****************************  END OPEN EDIT FORM WITH DATA ***************/


    /****************************  START UPDATE DATA *************************/
    public function update_data($id)
    {	
		$datas= $this->welcome->edit_data($id);
		if(!empty($_FILES['user_image']['name']))
		{
			
		$upload_data = $this->welcome->do_upload('user_image');
		$file_name = $upload_data['file_name'];
		$delete_file = $datas[0]['user_image'];
					$path = "assets/uploaded_profile_pictures/".$delete_file;
					unlink($path);
			
		}
		else 
				{
					$file_name=$datas[0]['user_image'];
				}	
    $data = array('username'                   => $this->input->post('username'),
                  'email'                      => $this->input->post('email'),
                  'sex'                        => $this->input->post('sex'),
                  'address'                    => $this->input->post('address'),
                  'user_image' => $file_name,
                  'created_date'               => date("m/d/y h:i:s"),
                  'status'                     => 'Y');
    $this->db->where('id', $id);
    $this->db->update('user_data', $data);
    $this->session->set_flashdata('message', 'Your data updated Successfully..');
    redirect('welcome/index');
    }
    /****************************  END UPDATE DATA ****************************/


    /****************************  START DELETE DATA **************************/
    public function delete_data($id)
    {  
    $this->db->where('id', $id);
    $this->db->delete('user_data');
    $this->session->set_flashdata('message', 'Your data deleted Successfully..');
    redirect('welcome/index');
    }
    /****************************  END DELETE DATA ***************************/
    
    public function pagination()
	{
		
	$config = array();
	$config["base_url"] = base_url() .'welcome/index';
	$total_row = $this->welcome->record_count();
	$config["total_rows"] = $total_row;
	$config["per_page"] = 10;
	$config['use_page_numbers'] = TRUE;
	$config['num_links'] = $total_row; // 2//decides how many link there besides both sides of current link.
	$config['cur_tag_open'] = '&nbsp;<a class="active">';
	$config['cur_tag_close'] = '</a>';
	$config['next_link'] = 'Next';
	$config['prev_link'] = 'Previous';
	
	$this->pagination->initialize($config);

	if($this->uri->segment(3))
	{	
		$page = ($this->uri->segment(3)) ;
	}
	else
	{
		$page = 1;
	}
	$data['view_data'] = $this->welcome->fetch_data($config["per_page"], $page);
	$str_links = $this->pagination->create_links();
	$data['links'] = explode('&nbsp;',$str_links );
	$this->load->view('header');
	
	$this->load->view('welcome_message', $data, FALSE);
	$this->load->view('footer');
	
	}
    
}
?>
